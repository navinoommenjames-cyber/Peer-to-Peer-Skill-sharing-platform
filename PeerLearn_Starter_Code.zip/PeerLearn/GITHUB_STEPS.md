# Upload PeerLearn to GitHub (Windows + VS Code)

## 1. Create a repository
1. Sign in at https://github.com
2. Click **+** → **New repository**.
3. Name it `PeerLearn`.
4. Choose **Private** if this is a college group project.
5. Leave **Add a README**, `.gitignore`, and license unchecked because this folder already contains files for those purposes.
6. Click **Create repository** and keep the page open.

## 2. Open the project folder
1. Extract `PeerLearn.zip`.
2. In VS Code, select **File → Open Folder**.
3. Select the extracted `PeerLearn` folder (the folder containing `index.html` and `README.md`).
4. Select **Terminal → New Terminal**.

## 3. Set Git identity (only needed once per laptop)
Replace the example values with your name and GitHub email:
```powershell
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

## 4. Upload the files
Replace `YOUR_USERNAME` with your GitHub username. Run each command in the VS Code terminal, from inside the PeerLearn folder:

```powershell
git init
git branch -M main
git add .
git commit -m "Add PeerLearn frontend demo"
git remote add origin https://github.com/YOUR_USERNAME/PeerLearn.git
git push -u origin main
```

GitHub may open a browser window to authenticate you. Follow the prompt. Never share your password or access token in chat.

### If `remote origin already exists`
Run:
```powershell
git remote -v
```
Check the URL before changing anything. Ask for help if it points to a different repository.

### If the first push is rejected
If you initialized the GitHub repository with a README, the remote may already contain a commit. Don't force-push. Share the error message so the two histories can be combined safely.

## 5. Later, after editing files
```powershell
git add .
git commit -m "Describe your changes"
git push
```

## 6. Share with teammates
For a private repository, open GitHub → repository **Settings** → **Collaborators** (or **Collaborators and teams**) and invite teammates by their GitHub usernames. They must accept the invitation. Do not put passwords, API keys, or private student information in the repository.
