# PeerLearn — Skill Matching Demo

PeerLearn is a starter frontend for a student peer-to-peer knowledge-sharing and skill-matching system.

## Features in this demo
- Browse sample student profiles.
- Search by name, skill, interest, or category.
- Filter profiles by category.
- Add a student profile.
- Save added profiles in the current browser using `localStorage`.
- Responsive layout for laptop and mobile screens.

## Run locally
1. Extract the ZIP file.
2. Open the extracted `PeerLearn` folder in VS Code.
3. Open `index.html`.
4. Easiest option: open `index.html` in your browser from File Explorer.

No Node.js, database, Maven, or Gradle download is needed for this frontend demo.

## Important limitations
This is a frontend prototype only. It does not have a Java backend, real user authentication, a shared database, or actual messaging. Profiles added in one browser are not automatically shared with teammates. Those features require a backend and database after the project requirements are confirmed.

## Suggested GitHub workflow
See `GITHUB_STEPS.md` for instructions to create a repository and upload the files.
